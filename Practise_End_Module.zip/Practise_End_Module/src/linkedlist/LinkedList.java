package linkedlist;

public class LinkedList {
	private Node head;

	public LinkedList() {
		this.head = null;
	}

	public Node getHead() {
		return head;
	}

	public void setHead(Node head) {
		this.head = head;
	}

	public boolean insert(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return true;
		}
		Node temp = head;
		while (temp.getNext() != null) {
			temp = temp.getNext();
		}
		temp.setNext(newNode);
		return true;
	}

	public void display() {
		Node temp = head;
		while (temp != null) {
			System.out.print(temp.getData() + " ");
			temp = temp.getNext();
		}
		System.out.println();
	}

	public void length() {
		Node temp = head;
		int count = 0;
		while (temp != null) {
			temp = temp.getNext();
			count++;
		}
		System.out.println("The Length of list: " + count);
	}

	public boolean insertAtPosition(int data, int position) {
		Node newNode = new Node(data);
		if (position <= 0 || (head == null && position > 1)) {
			return false;
		}
		if (position == 1) {
			if (head == null) {
				head = newNode;
				return true;
			}
			newNode.setNext(head);
			head = newNode;
			return true;
		}
		Node prev = head;
		for (int i = 1; i < position - 1; i++) {
			prev = prev.getNext();
			if (prev == null) {
				return false;
			}
		}
		newNode.setNext(prev.getNext());
		prev.setNext(newNode);
		return true;
	}

	public boolean deletAtPosition(int position) {
		if (position <= 0 || (head == null && position > 1)) {
			return false;
		}
		if (position == 1) {
			if (head == null) {
				return false;
			}
			head = head.getNext();
			return true;
		}
		Node temp = head;
		for (int i = 1; i < position - 1; i++) {
			temp = temp.getNext();
			if (temp == null) {
				return false;
			}
		}
		temp.setNext(temp.getNext().getNext());
		return true;
	}

	public boolean deleteByData(int data) {
		if (head == null) {
			return false;
		}
		if(head.getData()==data) {
			head = head.getNext();
			return true;
		}
		Node prev = head;
		Node current = head.getNext();
		while(current!=null &&current.getData()!=data) {
			prev = current;
			current = current.getNext();
			if(current==null) {
				return false;
			}
		}
		prev.setNext(current.getNext());
		return true;
	}
	
	
	public boolean remove() {
		if(head==null) {
			return false;
		}
		if(head.getNext()==null) {
			head=null;
			return true;
		}
		Node temp  = head;
		while(temp.getNext().getNext()!=null) {
			temp = temp.getNext();
		}
		temp.setNext(null);
		return true;
	}
	
	public int max() {
		int max = Integer.MIN_VALUE;
		Node temp = head;
		while(temp!=null) {
			if(temp.getData() > max) {
				max= temp.getData();	
			}
			temp = temp.getNext();
		}
		return max;
		
	}
	
	public int min() {
		int min = Integer.MAX_VALUE;
		Node temp = head;
		while(temp!=null) {
			if(temp.getData() < min) {
				min= temp.getData();	
			}
			temp = temp.getNext();
		}
		return min;
		
	}
	
	public void reverseList(Node temp) {
		if(temp==null) {
			System.out.println();
			return;
		}
		reverseList(temp.getNext());
		System.out.println(temp.getData()+" ");
	}

}