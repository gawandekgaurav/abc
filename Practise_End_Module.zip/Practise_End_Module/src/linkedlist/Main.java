package linkedlist;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		try(Scanner sc = new Scanner(System.in)){
			LinkedList l1 = new LinkedList();
			boolean exit = false;
		try {
			while(!exit) {
			System.out.println("1.Insert data into linked list\n" +"2.Display\n"
			+"3.Length\n"+"4.Insert at position\n"+"5.Delete by position\n"
					+"6.Delete by data\n"+"7.Find max\n"+"8.Find min\n"
			+"9.Reverse List\n"
					+"10.Remove\n"+"11.Exit");			
			System.out.println("Enter your choice");
			switch (sc.nextInt()) {
			case 1:
				System.out.println("Enter the num of elements you want to insert");
				int size=sc.nextInt();
				for(int i=0;i<size;i++) {
					System.out.println("Enter the elements");
					l1.insert(sc.nextInt());
				}
				break;
			case 2:
				l1.display();
				break;
			case 3:
				l1.length();
				break;
			case 4:
				System.out.println("Enter the data and position");
				l1.insertAtPosition(sc.nextInt(), sc.nextInt());
				break;
			case 5:
				System.out.println("Enter the position");
				l1.deletAtPosition(sc.nextInt());
				break;
			case 6:
				System.out.println("Enter data");
				l1.deleteByData(sc.nextInt());
				break;
			case 7:
				System.out.println(l1.max());
				break;
			case 8:
				System.out.println(l1.min());
				break;
			case 9:
				l1.reverseList(l1.getHead());
				break;
			case 10:
				l1.remove();
				break;
			case 11: 
			System.out.println("Exiting.....");
			break;
			default:
				break;
			}
			
			
			
			}
			
		}catch(Exception e) {
			e.getStackTrace();
		}
			
			
		}

	}

}
