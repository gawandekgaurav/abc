package com.example.playerservice.entity;

public enum SportType {
    INDOOR, OUTDOOR
}
