package com.app.entity;

public enum SportType {
    INDOOR, OUTDOOR
}
