package com.app.entity;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name="players")
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique=true)
    private Long playerId;

    @NotBlank
    @Column(name="playerName", nullable = true)

    private String playerName;
    
    @Column(name="sportsType", nullable = true)
    @Enumerated(EnumType.STRING)
    private SportType sportType;

    @NotBlank
    @Column(name="contact", nullable = true)
    private String contact;

    @Email
    @NotBlank
    @Column(name="email", nullable = true)
    private String email;

    @NotBlank
    @Column(name="address", nullable = true)
    private String address;

    @Column(name="sportsPoint", nullable = true)
    @Min(value = 250)
    @Max(value = 300)
    private int sportsPoints;

	public Long getPlayerId() {
		return playerId;
	}
	
	public Player() {}
	
	
	public Player(Long playerId, @NotBlank String playerName, SportType sportType, @NotBlank String contact,
			@Email @NotBlank String email, @NotBlank String address, @Min(250) @Max(300) int sportsPoints) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.sportType = sportType;
		this.contact = contact;
		this.email = email;
		this.address = address;
		this.sportsPoints = sportsPoints;
	}



	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public SportType getSportType() {
		return sportType;
	}

	public void setSportType(SportType sportType) {
		this.sportType = sportType;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getSportsPoints() {
		return sportsPoints;
	}

	public void setSportsPoints(int sportsPoints) {
		this.sportsPoints = sportsPoints;
	}

	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", playerName=" + playerName + ", sportType=" + sportType + ", contact="
				+ contact + ", email=" + email + ", address=" + address + ", sportsPoints=" + sportsPoints + "]";
	}
	
	

    // Getters and setters, constructors
}

