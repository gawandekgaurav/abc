package com.app.service;

import java.util.List;

import com.app.entity.Player;
import com.app.entity.SportType;

public interface PlayerService {
    Player addPlayer(Player player);
    Player updatePlayer(Long playerId, Player player);
    List<Player> getAllPlayersBySportType(SportType sportType);
    Player getPlayerById(Long playerId);
    void deletePlayer(Long playerId);
}
