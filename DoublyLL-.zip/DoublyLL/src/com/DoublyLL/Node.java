package com.DoublyLL;

public class Node {

	int Data;
	Node prev;
	Node next;
	
	public Node(int Data)
	{
		this.Data = Data;
		this.prev = null;
		this.next = null;
	}
}
